const tracks = [
  {id:1,title:"Kum Gibi",album:"نمونه آثار",file:"audio/kum-gibi.mp3"},
  {id:2,title:"Şafak Türküsü",album:"نمونه آثار",file:"audio/safak-turkusu.mp3"},
  {id:3,title:"Kendine İyi Bak",album:"نمونه آثار",file:"audio/kendine-iyi-bak.mp3"},
  {id:4,title:"Yorgun Demokrat",album:"نمونه آثار",file:"audio/yorgun-demokrat.mp3"},
  {id:5,title:"Söyle",album:"نمونه آثار",file:"audio/soyle.mp3"},
  {id:6,title:"Nereden Bileceksiniz",album:"نمونه آثار",file:"audio/nereden-bileceksiniz.mp3"}
];
const $=id=>document.getElementById(id);
const audio=$("audio");let current=-1,filter="all",shuffle=false,repeat=false;
let favorites=JSON.parse(localStorage.getItem("ak-favorites")||"[]");
const fmt=s=>{if(!Number.isFinite(s))return"0:00";return Math.floor(s/60)+":"+String(Math.floor(s%60)).padStart(2,"0")};
function render(){
 const q=$("search").value.trim().toLocaleLowerCase();
 const shown=tracks.filter(t=>(filter==="all"||favorites.includes(t.id))&&t.title.toLocaleLowerCase().includes(q));
 $("trackCount").textContent=`${tracks.length} عنوان نمونه`;
 $("trackList").innerHTML=shown.map((t,i)=>`<article class="track ${tracks[current]?.id===t.id?"active":""}">
 <span class="track-num">${String(i+1).padStart(2,"0")}</span>
 <div class="track-info"><b>${t.title}</b><small>Ahmet Kaya · ${t.album}</small></div>
 <div class="track-actions"><button aria-label="پخش" onclick="playTrack(${t.id})">▶</button><button class="heart ${favorites.includes(t.id)?"on":""}" aria-label="علاقه‌مندی" onclick="toggleFav(${t.id})">♥</button></div></article>`).join("");
 $("empty").classList.toggle("hidden",shown.length>0);
}
function playTrack(id){
 const index=tracks.findIndex(t=>t.id===id);if(index<0)return;current=index;
 audio.src=tracks[current].file;$("nowTitle").textContent=tracks[current].title;
 $("status").textContent="در حال آماده‌سازی فایل صوتی…";
 audio.play().then(()=>{$("play").textContent="Ⅱ";$("status").textContent="در حال پخش آفلاین";}).catch(()=>{$("play").textContent="▶";$("status").textContent=`فایل ${tracks[current].file} موجود نیست. فایل صوتی مجاز را با همین نام در پوشه audio قرار بده.`;});
 render();
}
function toggleFav(id){favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];localStorage.setItem("ak-favorites",JSON.stringify(favorites));render()}
function step(dir){
 if(!tracks.length)return;
 if(shuffle&&tracks.length>1){let n;do{n=Math.floor(Math.random()*tracks.length)}while(n===current);current=n}
 else current=(current+dir+tracks.length)%tracks.length;
 playTrack(tracks[current].id);
}
$("search").addEventListener("input",render);
$("filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;filter=b.dataset.filter;document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===b));render()});
$("play").onclick=()=>{if(current<0){playTrack(tracks[0].id);return}if(audio.paused)audio.play().then(()=>$("play").textContent="Ⅱ").catch(()=>{});else audio.pause();$("play").textContent=audio.paused?"▶":"Ⅱ"};
$("prev").onclick=()=>step(-1);$("next").onclick=()=>step(1);
$("shuffle").onclick=()=>{shuffle=!shuffle;$("shuffle").style.color=shuffle?"#ef5368":"#ddd"};
$("repeat").onclick=()=>{repeat=!repeat;audio.loop=repeat;$("repeat").style.color=repeat?"#ef5368":"#ddd"};
audio.addEventListener("timeupdate",()=>{$("progress").value=audio.duration?audio.currentTime/audio.duration*100:0;$("currentTime").textContent=fmt(audio.currentTime);$("duration").textContent=fmt(audio.duration)});
$("progress").oninput=()=>{if(audio.duration)audio.currentTime=$("progress").value/100*audio.duration};
audio.addEventListener("ended",()=>{if(!repeat)step(1)});
let installPrompt;$("installBtn").classList.add("hidden");
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("installBtn").classList.remove("hidden")});
$("installBtn").onclick=async()=>{if(installPrompt){installPrompt.prompt();installPrompt=null;$("installBtn").classList.add("hidden")}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js"));
render();
